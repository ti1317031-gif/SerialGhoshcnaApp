# সিরিয়াল ঘোষণা অ্যাপ — APK বানানোর সহজ পদ্ধতি

এই প্রকল্পে GitHub Actions workflow যোগ করা হয়েছে। GitHub-এ প্রকল্পের ফাইল আপলোড করার পর Actions নিজে APK বানাবে।

## GitHub-এ আপলোড
1. একটি নতুন GitHub repository তৈরি করুন।
2. এই ZIP-এর ভেতরের `SerialGhoshonaApp` ফোল্ডারের **ভেতরের সব ফাইল ও ফোল্ডার** repository-এর মূল জায়গায় আপলোড করুন।
3. `.github/workflows/build-apk.yml` ফাইলটিও অবশ্যই থাকতে হবে।
4. GitHub-এর **Actions** ট্যাবে গিয়ে `Build SerialGhoshona APK` workflow খুলুন।
5. `Run workflow` চাপুন (যদি push-এর পর নিজে শুরু না হয়)।
6. কাজ শেষ হলে workflow-এর নিচে **Artifacts** থেকে `SerialGhoshona-debug-apk` ডাউনলোড করুন।

> এই পদ্ধতিতে ফোনে AndroidIDE ইনস্টল করার প্রয়োজন নেই।
