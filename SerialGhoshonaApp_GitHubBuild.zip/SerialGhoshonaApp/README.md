# সিরিয়াল ঘোষণা সিস্টেম

Android app for managing serial numbers and announcing them in Bangla using Text-to-Speech.

## Features
- বাংলা UI
- সিরিয়াল + নাম যোগ, edit, delete
- বাংলা Text-to-Speech ঘোষণা
- ঘোষণা / থামান / পরবর্তী সিরিয়াল
- অ্যাপ বন্ধ করলেও সিরিয়াল তালিকা সংরক্ষিত থাকে
- CSV ও সাধারণ XLSX import
- Portrait Android app

## APK build
1. Android Studio খুলুন।
2. এই `SerialGhoshona` folder খুলুন।
3. Gradle sync শেষ হতে দিন।
4. `Build > Build App Bundle(s) / APK(s) > Build APK(s)` নির্বাচন করুন।
5. Debug APK পাবেন: `app/build/outputs/apk/debug/app-debug.apk`

### বাংলা ভয়েস
ফোনের Text-to-Speech settings-এ বাংলা voice install/enable করে নিন।
