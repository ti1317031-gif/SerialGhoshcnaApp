package com.example.serialghoshona;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class MainActivity extends Activity {
    LinearLayout root, listBox;
    EditText serialInput, nameInput;
    TextToSpeech tts;
    ArrayList<Item> items = new ArrayList<>();
    int current = -1;
    float speechRate = 1.0f, volume = 1.0f;

    static class Item {
        String serial, name;
        Item(String s, String n){ serial=s; name=n; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadItems();
        buildUI();
        tts = new TextToSpeech(this, status -> {
            if(status == TextToSpeech.SUCCESS) {
                selectBanglaVoice();
                tts.setSpeechRate(speechRate);
                tts.setPitch(1.05f);
            }
        });
    }

    TextView tv(String text, float sp) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(sp); v.setTextColor(Color.DKGRAY);
        v.setPadding(10,8,10,8);
        return v;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(15);
        return b;
    }

    void buildUI() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248,250,253));

        TextView bar = tv("🔊  সিরিয়াল ঘোষণা সিস্টেম                         ⚙", 22);
        bar.setTextColor(Color.WHITE); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(18,10,10,10); bar.setBackgroundColor(Color.rgb(13,110,253));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(64)));

        LinearLayout form = new LinearLayout(this);
        form.setPadding(12,10,12,4);
        serialInput = new EditText(this); serialInput.setHint("সিরিয়াল নম্বর"); serialInput.setInputType(2);
        nameInput = new EditText(this); nameInput.setHint("নাম");
        form.addView(serialInput, new LinearLayout.LayoutParams(0,dp(58),1));
        form.addView(nameInput, new LinearLayout.LayoutParams(0,dp(58),1));
        Button add = btn("＋\nযোগ করুন");
        add.setOnClickListener(v -> addItem());
        form.addView(add, new LinearLayout.LayoutParams(dp(105),dp(58)));
        root.addView(form);

        LinearLayout actions = new LinearLayout(this);
        Button announce = btn("🔊 ঘোষণা করুন");
        Button stop = btn("■ থামান");
        Button next = btn("⏭ পরবর্তী সিরিয়াল");
        announce.setOnClickListener(v -> announceCurrent());
        stop.setOnClickListener(v -> { if(tts!=null) tts.stop(); });
        next.setOnClickListener(v -> nextItem());
        actions.addView(announce, new LinearLayout.LayoutParams(0,dp(55),1));
        actions.addView(stop, new LinearLayout.LayoutParams(0,dp(55),1));
        actions.addView(next, new LinearLayout.LayoutParams(0,dp(55),1));
        root.addView(actions);

        TextView title = tv("সিরিয়াল                         নাম                         কাজ",18);
        title.setGravity(Gravity.CENTER); title.setBackgroundColor(Color.rgb(220,235,252));
        root.addView(title);

        ScrollView scroll = new ScrollView(this);
        listBox = new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bottom = new LinearLayout(this);
        Button clear = btn("🗑 সব মুছুন");
        Button importBtn = btn("📄 Excel/CSV থেকে আমদানি");
        clear.setOnClickListener(v -> { items.clear(); current=-1; saveItems(); renderList(); });
        importBtn.setOnClickListener(v -> pickFile());
        bottom.addView(clear, new LinearLayout.LayoutParams(0,dp(58),1));
        bottom.addView(importBtn, new LinearLayout.LayoutParams(0,dp(58),2));
        root.addView(bottom);

        setContentView(root);
    }

    void addItem() {
        String s=serialInput.getText().toString().trim();
        String n=nameInput.getText().toString().trim();
        if(s.isEmpty() || n.isEmpty()) { Toast.makeText(this,"সিরিয়াল নম্বর ও নাম দিন",Toast.LENGTH_SHORT).show(); return; }
        items.add(new Item(s,n)); serialInput.setText(""); nameInput.setText(""); saveItems(); renderList();
    }

    void renderList() {
        listBox.removeAllViews();
        for(int i=0;i<items.size();i++){
            final int idx=i; Item it=items.get(i);
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(8,2,8,2);
            TextView a=tv(it.serial,17); a.setGravity(Gravity.CENTER);
            TextView b=tv(it.name,17); b.setGravity(Gravity.CENTER);
            Button say=btn("🔊"); Button edit=btn("✎"); Button del=btn("🗑");
            say.setOnClickListener(v->{current=idx; announceCurrent();});
            edit.setOnClickListener(v->editItem(idx));
            del.setOnClickListener(v->{items.remove(idx); if(current>=items.size())current=items.size()-1; saveItems(); renderList();});
            row.addView(a,new LinearLayout.LayoutParams(0,dp(55),1));
            row.addView(b,new LinearLayout.LayoutParams(0,dp(55),2));
            row.addView(say,new LinearLayout.LayoutParams(dp(52),dp(52)));
            row.addView(edit,new LinearLayout.LayoutParams(dp(52),dp(52)));
            row.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));
            listBox.addView(row);
        }
    }

    void editItem(int idx) {
        EditText s=new EditText(this); s.setText(items.get(idx).serial); s.setHint("সিরিয়াল");
        EditText n=new EditText(this); n.setText(items.get(idx).name); n.setHint("নাম");
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,0,30,0);
        box.addView(s); box.addView(n);
        new AlertDialog.Builder(this).setTitle("সিরিয়াল পরিবর্তন").setView(box)
            .setPositiveButton("সংরক্ষণ",(d,w)->{String ns=s.getText().toString().trim(), nn=n.getText().toString().trim(); if(!ns.isEmpty()&&!nn.isEmpty()){items.set(idx,new Item(ns,nn));saveItems();renderList();}})
            .setNegativeButton("বাতিল",null).show();
    }

    void announceCurrent() {
        if(items.isEmpty()){Toast.makeText(this,"আগে সিরিয়াল যোগ করুন",Toast.LENGTH_SHORT).show();return;}
        if(current<0 || current>=items.size()) current=0;
        Item it=items.get(current);
        String text="সিরিয়াল নাম্বার "+it.serial+", নাম "+it.name+"। দয়া করে সামনে আসুন।";
        if(tts!=null) tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"serial");
    }

    void nextItem() {
        if(items.isEmpty()) return;
        current=(current+1)%items.size(); announceCurrent();
    }

    void selectBanglaVoice() {
        if(tts==null) return;
        Voice best=null;
        for(Voice v: tts.getVoices()){
            Locale l=v.getLocale();
            if(l.getLanguage().equals("bn")){
                if(best==null) best=v;
                String name=v.getName().toLowerCase(Locale.US);
                if(name.contains("female") || name.contains("woman") || name.contains("zira")) {best=v;break;}
            }
        }
        if(best!=null) tts.setVoice(best);
    }

    void pickFile() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,42);
    }

    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);
        if(r==42 && c==RESULT_OK && data!=null){
            try{
                String name=getName(data.getData());
                if(name.toLowerCase().endsWith(".xlsx")) importXlsx(data.getData());
                else importCsv(data.getData());
            }catch(Exception e){Toast.makeText(this,"ফাইল পড়তে সমস্যা: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }

    String getName(Uri u){
        try (android.database.Cursor c=getContentResolver().query(u,null,null,null,null)) {
            if(c!=null && c.moveToFirst()) {
                int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(i>=0) return c.getString(i);
            }
        } catch(Exception ignored) {}
        String p=u.getPath(); return p==null?"file.csv":p;
    }

    void importCsv(Uri uri)throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri),StandardCharsets.UTF_8));
        String line; int count=0;
        while((line=br.readLine())!=null){
            String[] x=line.split(",",-1);
            if(x.length>=2){
                String s=x[0].trim(), n=x[1].trim();
                if(!s.isEmpty() && !n.isEmpty() && !s.equalsIgnoreCase("serial")){items.add(new Item(s,n));count++;}
            }
        }
        br.close(); saveItems(); renderList(); Toast.makeText(this,count+"টি সিরিয়াল আমদানি হয়েছে",Toast.LENGTH_SHORT).show();
    }

    void importXlsx(Uri uri)throws Exception{
        InputStream in=getContentResolver().openInputStream(uri);
        File tmp=new File(getCacheDir(),"import.xlsx");
        FileOutputStream out=new FileOutputStream(tmp); byte[] buf=new byte[8192]; int len;
        while((len=in.read(buf))>0)out.write(buf,0,len); in.close(); out.close();

        ZipFile z=new ZipFile(tmp);
        HashMap<String,String> shared=new HashMap<>();
        ZipEntry ss=z.getEntry("xl/sharedStrings.xml");
        if(ss!=null){
            Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(z.getInputStream(ss));
            NodeList si=d.getElementsByTagName("si");
            for(int i=0;i<si.getLength();i++){
                NodeList ts=((Element)si.item(i)).getElementsByTagName("t");
                StringBuilder val=new StringBuilder();
                for(int j=0;j<ts.getLength();j++)val.append(ts.item(j).getTextContent());
                shared.put(String.valueOf(i),val.toString());
            }
        }
        ZipEntry sheet=z.getEntry("xl/worksheets/sheet1.xml");
        if(sheet==null){z.close();return;}
        Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(z.getInputStream(sheet));
        NodeList rows=d.getElementsByTagName("row");
        for(int i=0;i<rows.getLength();i++){
            NodeList cells=((Element)rows.item(i)).getElementsByTagName("c");
            String[] vals=new String[2];
            for(int j=0;j<cells.getLength();j++){
                Element c=(Element)cells.item(j);
                String ref=c.getAttribute("r"); if(ref.isEmpty())continue;
                int col=ref.charAt(0)-'A'; if(col>1)continue;
                NodeList vs=c.getElementsByTagName("v"); if(vs.getLength()==0)continue;
                String val=vs.item(0).getTextContent();
                if("s".equals(c.getAttribute("t"))) val=shared.getOrDefault(val,"");
                vals[col]=val;
            }
            if(vals[0]!=null && vals[1]!=null && !vals[0].equalsIgnoreCase("serial")) items.add(new Item(vals[0].trim(),vals[1].trim()));
        }
        z.close(); saveItems(); renderList(); Toast.makeText(this,"Excel থেকে সিরিয়াল আমদানি হয়েছে",Toast.LENGTH_SHORT).show();
    }

    void saveItems(){
        android.content.SharedPreferences p=getSharedPreferences("serial_data",MODE_PRIVATE);
        StringBuilder b=new StringBuilder();
        for(Item it:items){ b.append(android.util.Base64.encodeToString(it.serial.getBytes(StandardCharsets.UTF_8),android.util.Base64.NO_WRAP)).append("\t").append(android.util.Base64.encodeToString(it.name.getBytes(StandardCharsets.UTF_8),android.util.Base64.NO_WRAP)).append("\n"); }
        p.edit().putString("items",b.toString()).apply();
    }

    void loadItems(){
        String raw=getSharedPreferences("serial_data",MODE_PRIVATE).getString("items","");
        if(raw.isEmpty()) return;
        for(String line:raw.split("\n")){
            if(line.trim().isEmpty()) continue;
            String[] x=line.split("\t",2);
            if(x.length==2){ try { items.add(new Item(new String(android.util.Base64.decode(x[0],android.util.Base64.DEFAULT),StandardCharsets.UTF_8),new String(android.util.Base64.decode(x[1],android.util.Base64.DEFAULT),StandardCharsets.UTF_8))); } catch(Exception ignored){} }
        }
    }

    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
